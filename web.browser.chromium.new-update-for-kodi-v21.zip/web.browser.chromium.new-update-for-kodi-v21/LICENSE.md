Kodi addon web.browser.chromium is provided under

    SPDX-License-Identifier: GPL-3.0-or-later


Being under the terms of the GNU General Public License v3.0 or later, according with

    LICENSES/LICENSE.GPL-3-or-later


In addition, other licenses may also apply. Please see

    LICENSES/README.md

for more details.

