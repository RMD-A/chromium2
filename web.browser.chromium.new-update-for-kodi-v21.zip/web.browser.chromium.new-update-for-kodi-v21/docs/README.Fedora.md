![Logo](resources/banner_slim.png)

# Fedora build guide

Currently not supported on this OS!