![Logo](resources/banner_slim.png)

# Ubuntu guide

Currently not available as packages!