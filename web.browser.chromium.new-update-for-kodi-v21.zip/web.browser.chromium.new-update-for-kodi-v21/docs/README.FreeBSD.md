![Logo](resources/banner_slim.png)

# FreeBSD build guide

Currently not supported on this OS!