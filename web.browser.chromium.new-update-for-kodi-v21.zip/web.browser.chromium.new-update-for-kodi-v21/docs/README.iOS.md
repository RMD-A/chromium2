![Logo](resources/banner_slim.png)

# iOS build guide

Currently not supported on this OS!