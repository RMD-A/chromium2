![Logo](resources/banner_slim.png)

# Android build guide

Currently not supported on this OS!